<?php

$servidor = "localhost";
$usuario = "id15361524_root";
$senha = "DogtechBR@2020";
$dbname = "id15361524_banco_petshop";

//Criar a conexão
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
?>